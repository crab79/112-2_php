-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： localhost:3306
-- 產生時間： 2024 年 06 月 13 日 05:03
-- 伺服器版本： 10.5.20-MariaDB
-- PHP 版本： 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `id22207720_project`
--
CREATE DATABASE IF NOT EXISTS `id22207720_project` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `id22207720_project`;

-- --------------------------------------------------------

--
-- 資料表結構 `boss`
--

CREATE TABLE `boss` (
  `bNo` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `pwd` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `boss`
--

INSERT INTO `boss` (`bNo`, `name`, `pwd`, `email`) VALUES
(1, '張大哥', 'boss1', 'boss1@yahoo.com'),
(2, '張二哥', 'boss2', 'boss2@yahoo.com'),
(3, '員工', 'employee', 'employee@yahoo.com');

-- --------------------------------------------------------

--
-- 資料表結構 `cart`
--

CREATE TABLE `cart` (
  `No` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `amount` int(5) NOT NULL,
  `price` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `customer`
--

CREATE TABLE `customer` (
  `mId` int(8) NOT NULL,
  `cName` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `homeTel` varchar(8) DEFAULT NULL,
  `homeAddress` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `customer`
--

INSERT INTO `customer` (`mId`, `cName`, `email`, `pwd`, `phone`, `homeTel`, `homeAddress`) VALUES
(1, '', '123@yahoo.com', '', '0911222333', '', '新北市板橋區民權路12巷1號'),
(2, '', '456@yahoo.com', '', '0922333444', '24927788', '高雄市楠梓區民權路12巷1號'),
(3, '', '789@yahoo.com', '', '0933444556', '24927799', '高雄市楠梓區民權路77巷1號'),
(4, '', '12223@yahoo.com', 'test5678', '0911222345', '24923333', '高雄市楠梓區民權路15巷1號'),
(5, '陳小明', '12113@yahoo.com', '12345aa', '0911409777', '24928899', '新北市板橋區民權路112巷1號'),
(7, '李小明', '123789@hhh.com', 'hhh123', '0911789012', '24925566', '高雄市楠梓區民權路125巷1號'),
(8, '測試', 'test@yahoo.com', 'test', '0912345678', '', '新北市萬里區北極里'),
(9, 'Qi', 'qqqq@gmail.com', '05300830', '0977777777', '', '台南'),
(11, '寒搖', 'a1091106@mail.nuk.edu.tw', 'a1091106', '0912547898', '', '高雄市');

-- --------------------------------------------------------

--
-- 資料表結構 `orders_list`
--

CREATE TABLE `orders_list` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `customer` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `orders_list`
--

INSERT INTO `orders_list` (`id`, `date`, `customer`, `status`, `amount`, `details`) VALUES
(26, '2024-06-20 02:35:45', '李小明', '未出貨', 230.00, '芝麻花生硬糖 1'),
(27, '2024-06-10 02:35:45', '李小明', '未出貨', 200.00, '原味麻花捲 1'),
(28, '2024-06-10 02:35:45', '李小明', '未出貨', 50.00, '捲心酥 1'),
(35, '2024-06-08 02:50:30', '陳小明', '未出貨', 220.00, '芝麻硬糖 1'),
(36, '2024-06-08 02:50:30', '陳小明', '未出貨', 200.00, '花生硬糖 1'),
(38, '2024-06-12 05:50:06', '陳小明', '未出貨', 230.00, '芝麻花生硬糖 1'),
(39, '2024-06-12 05:50:06', '陳小明', '未出貨', 180.00, '原味麻花捲 1'),
(40, '2024-06-12 05:50:06', '陳小明', '未出貨', 50.00, '卡哩卡哩 1'),
(41, '2024-06-12 13:31:38', '陳小明', '未出貨', 600.00, '花生硬糖 3'),
(42, '2024-06-12 13:31:38', '陳小明', '未出貨', 180.00, '原味麻花捲 1'),
(43, '2024-06-12 13:31:38', '陳小明', '未出貨', 100.00, '綠豆糕 1'),
(49, '2024-06-13 03:01:25', '寒搖', '未出貨', 200.00, '花生硬糖 1'),
(50, '2024-06-13 03:01:25', '寒搖', '未出貨', 50.00, '捲心酥 1');

-- --------------------------------------------------------

--
-- 資料表結構 `product_crispy`
--

CREATE TABLE `product_crispy` (
  `No` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `price` int(5) NOT NULL,
  `description` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `product_crispy`
--

INSERT INTO `product_crispy` (`No`, `name`, `price`, `description`, `img`) VALUES
(1, '原味脆枝', 200, '本產品是手工製作的原味脆枝，選用上等原料，精心烘焙而成。口感香脆，濃郁自然的香氣帶來純粹的味覺享受。適合作為日常零食或聚會小點心。', 'https://decing.tw/wp-content/uploads/20190511171209_67.jpg'),
(2, '薑味脆枝', 190, '本產品是手工製作的薑味脆枝，選用上等薑與優質原料，精心烘焙而成。口感香脆，帶有微辣的薑香，獨特風味讓人回味無窮。適合作為日常零食或聚會小點心。', 'https://hululu.tw/wp-content/uploads/pixnet/ccdde6f7fe44e15098f7aaef843eb06f.jpg'),
(3, '黑糖脆枝', 200, '本產品是手工製作的黑糖脆枝，選用上等黑糖與優質原料，精心烘焙而成。口感香脆，甜而不膩，濃郁的黑糖香氣讓人一試成主顧。適合作為日常零食或聚會小點心。', 'https://down-tw.img.susercontent.com/file/tw-11134207-23020-wrk68au218mv85_tn'),
(4, '原味麻花捲', 180, '本產品是手工製作的原味麻花捲，選用上等原料，精心烘焙而成。口感香脆，濃郁自然的香氣帶來純粹的味覺享受。適合作為日常零食或聚會小點心。', 'https://www.newsmarket.com.tw/shop/files/2024/01/%E9%BA%BB%E8%8A%B1%E6%8D%B2-%E5%8E%9F%E5%91%B3-0J2A0195-800.jpg'),
(5, '薑味麻花捲', 190, '本產品是手工製作的薑味麻花捲，選用上等薑與優質原料，精心烘焙而成。口感香脆，帶有微辣的薑香，獨特風味讓人回味無窮。適合作為日常零食或聚會小點心。', 'https://shopping.line-scdn.net/0h7Ro0T9o8aH1SSXsF68oXKgoUdAw6PzFqLXFyXyUMKB8keGpUbEx9SCw6fjEZDWd5G30icC8ifSwZOGlUNkQmehEpahgaeGZDNURuSxE2ax0JBWRVG19uYCsTPjEf'),
(6, '黑糖麻花捲', 200, '本產品是手工製作的黑糖麻花捲，選用上等黑糖與優質原料，精心烘焙而成。口感香脆，甜而不膩，濃郁的黑糖香氣讓人一試成主顧。適合作為日常零食或聚會小點心。', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUvY3K2wd6qPWXc5N3_T8rr8CihY1cT4z9kg&s');

-- --------------------------------------------------------

--
-- 資料表結構 `product_otherCandy`
--

CREATE TABLE `product_otherCandy` (
  `No` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `price` int(5) NOT NULL,
  `description` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `product_otherCandy`
--

INSERT INTO `product_otherCandy` (`No`, `name`, `price`, `description`, `img`) VALUES
(1, '捲心酥', 50, '本產品是手工製作的捲心酥，選用上等原料，口感酥脆，內餡香甜綿密。每一口都充滿濃郁的香氣，讓人回味無窮。適合作為日常小零食或節慶贈禮。', 'https://www.dl-food.com/wp-content/uploads/RM2.jpg'),
(2, '卡哩卡哩', 50, '本產品是手工製作的卡哩卡哩，選用上等原料，口感香脆，帶有獨特的卡哩風味。每一口都充滿異國風情，讓人愛不釋手。適合作為日常小零食或聚會小點心。', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_Y66CabWiseqCuajzKKFnGUxSlRn2vQny4g&s'),
(3, '巧克力', 50, '本產品是手工製作的巧克力，選用上等可可豆，口感香濃順滑，甜而不膩。每一口都充滿濃郁的巧克力香氣，帶來極致的味覺享受。適合作為日常小零食或節慶贈禮。', 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Chocolate_%28blue_background%29.jpg/800px-Chocolate_%28blue_background%29.jpg'),
(4, '綠豆糕', 100, '本產品是綠豆糕，選用上等綠豆與優質原料製作而成。口感綿密細膩，清香可口，甜而不膩。適合作為下午茶點或休閒零食。', 'https://tokyo-kitchen.icook.network/uploads/recipe/cover/356119/4ca8b3c066dd5de9.jpg'),
(5, '汽水糖', 100, '本產品是汽水糖，口感柔軟，入口即化，帶有淡淡的汽水味道，清新怡人。無添加防腐劑，健康美味，是孩子們的最愛。適合作為午後小點心或外出時的隨身零食。', 'https://down-tw.img.susercontent.com/file/bb2fee92843859a44565621a2754f522'),
(6, '孔雀餅乾', 100, '本產品是孔雀餅乾，造型優美，口感酥脆。選用上等小麥與精選原料製作而成，每一口都帶來濃郁的餅香。適合作為下午茶點或休閒零食。', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRayTpXOgu7QY6pgEbyt_UPJlzJJRb0_hacLg&s');

-- --------------------------------------------------------

--
-- 資料表結構 `product_peanut`
--

CREATE TABLE `product_peanut` (
  `No` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `price` int(5) NOT NULL,
  `description` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 傾印資料表的資料 `product_peanut`
--

INSERT INTO `product_peanut` (`No`, `name`, `price`, `description`, `img`) VALUES
(1, '花生硬糖', 200, '本產品是手工製作的花生硬糖，選用上等花生與純天然原料，口感香脆，甜而不膩。每一口都充滿濃郁的花生香氣，帶來美妙的味覺享受。适合作為日常小零食或節慶贈禮。', 'https://www.hug.com.tw/uploads/images/product_photos/p_o_1dse9uqlacoc1eiv3bkesa1lat7.jpg'),
(2, '花生軟糖', 200, '「花生軟糖」，軟糯香甜，入口即化，每一口都充滿濃郁的花生香氣。精選優質花生和天然原料精製而成，健康美味，是休閒時光的理想伴侶。無論自享還是送禮，都能帶來滿滿的幸福感！', 'https://chancandy.com/wp-content/uploads/2023/02/02s-600x474.jpg'),
(3, '竹炭花生', 200, '脆香可口，竹炭的獨特風味與花生的濃郁香氣完美融合，給您帶來非凡的味覺體驗。精選上等花生，經過細緻烘焙，健康美味，是您休閒時光的最佳夥伴。無論自享還是送禮，都是絕佳選擇！', 'https://bamboofood.weebly.com/uploads/4/9/6/6/49669615/s969577675782431974_p4_i5_w640.png'),
(4, '芝麻硬糖', 220, '本產品是手工製作的芝麻硬糖，選用上等芝麻與純天然原料，口感香脆，甜而不膩。每一口都充滿濃郁的芝麻香氣，帶來美妙的味覺享受。適合作為日常小零食或節慶贈禮。', 'https://img.ltn.com.tw/Upload/food/page/2024/02/20/240220-12408-6-Bt7g7.jpg'),
(5, '芝麻軟糖', 210, '本產品是手工製作的芝麻軟糖，選用上等芝麻與純天然原料，口感軟糯，甜而不膩。每一口都充滿濃郁的芝麻香氣，帶來美妙的味覺享受。適合作為日常小零食或節慶贈禮。', 'https://www.hucc-coop.tw/uploads/01%E7%94%A2%E5%93%81%E8%88%87%E7%94%9F%E7%94%A2%E8%80%85/%E7%94%A2%E5%93%81%E5%9C%96%E6%AA%94/%E8%AA%BF%E7%90%86%E9%A3%9F%E6%9D%90/%E7%B3%96%E6%9E%9C_%E5%B7%A7%E5%85%8B%E5%8A%9B/%E9%BB%91%E8%8A%9D%E9%BA%BB%E9%BA%A5%E8%8A%BD%E8%BB%9F%E7%B3%96B.jpg'),
(6, '芝麻花生硬糖', 230, '本產品是手工製作的芝麻花生硬糖，選用上等芝麻與花生，配合純天然原料，口感香脆，甜而不膩。每一口都充滿濃郁的芝麻與花生香氣，帶來美妙的味覺享受。適合作為日常小零食或節慶贈禮。', 'https://cdn02.pinkoi.com/product/FZKtdDkg/3/640x530.jpg'),
(7, '芝麻花生軟糖', 220, '本產品是手工製作的芝麻花生軟糖，選用上等芝麻與花生，配合純天然原料，口感軟糯，甜而不膩。每一口都充滿濃郁的芝麻與花生香氣，帶來美妙的味覺享受。適合作為日常小零食或節慶贈禮。', 'https://cdn02.pinkoi.com/product/FZKtdDkg/3/640x530.jpg');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `boss`
--
ALTER TABLE `boss`
  ADD PRIMARY KEY (`bNo`);

--
-- 資料表索引 `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`No`);

--
-- 資料表索引 `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`mId`);

--
-- 資料表索引 `orders_list`
--
ALTER TABLE `orders_list`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `product_crispy`
--
ALTER TABLE `product_crispy`
  ADD PRIMARY KEY (`No`);

--
-- 資料表索引 `product_otherCandy`
--
ALTER TABLE `product_otherCandy`
  ADD PRIMARY KEY (`No`);

--
-- 資料表索引 `product_peanut`
--
ALTER TABLE `product_peanut`
  ADD PRIMARY KEY (`No`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `boss`
--
ALTER TABLE `boss`
  MODIFY `bNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `cart`
--
ALTER TABLE `cart`
  MODIFY `No` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `customer`
--
ALTER TABLE `customer`
  MODIFY `mId` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `orders_list`
--
ALTER TABLE `orders_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product_crispy`
--
ALTER TABLE `product_crispy`
  MODIFY `No` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product_otherCandy`
--
ALTER TABLE `product_otherCandy`
  MODIFY `No` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product_peanut`
--
ALTER TABLE `product_peanut`
  MODIFY `No` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
