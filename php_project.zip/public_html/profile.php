<!DOCTYPE html>
<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}


function fetchInfoFromDatabase($link) {
    $datas = [];

    if(isset($_COOKIE["userInfo"])) {
        // Retrieve the JSON string from the cookie
        $userInfoJson = $_COOKIE["userInfo"];
    
        // Convert the JSON string back to an associative array
        $userInfo = json_decode($userInfoJson, true);
    
        // Access the individual pieces of data
        $userName = $userInfo["userName"];
        $date = $userInfo["date"];
        $userEmail = $userInfo["userEmail"];
        $userPwd = $userInfo["userPwd"];

        // Use prepared statement to prevent SQL injection
        $stmt = $link->prepare("SELECT *
                                FROM customer
                                WHERE email = ? AND pwd = ?");
        $stmt->bind_param("ss", $userEmail, $userPwd);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $datas[] = $row;
            }
        } else {
            echo "錯誤: " . $stmt->error;
        }

        $stmt->close();
    }

    return $datas;
}

// 獲取訂單資料
$datas = fetchInfoFromDatabase($link);

mysqli_close($link);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="profile.bundle.js"></script>
</head>
<body>
    <div class="header">
        <h2 id="title"><a href="index.php">世芳軒</a></h2>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "user") {
                echo "<div class='nav'>
                        <a href='products.php'>查看所有商品</a>
                        <a href='profile.php'>個人資料</a>    
                        <a href='cart.php'>購物車</a>
                        <a href='logout.php'>登出</a>
                      </div>";           
            } else if ($_SESSION["check"] == "guest") {
                echo "<script type='text/javascript'>
                        alert(\"載入失敗\\n請登入後再查看此網頁\");
                        window.location.href = 'login.html';
                    </script>";
            }
        }
        ?>
    </div>
    <div class="content">
        <div class="border">
            <?php if (!empty($datas)) : ?>
                <h2>個人資料</h2>
                <div class="info">
                    <?php foreach ($datas as $data): ?>
                        <p>姓名：<?= htmlspecialchars($data['cName'], ENT_QUOTES, 'UTF-8') ?></p>
                        <p>電子郵件：<?= htmlspecialchars($data['email'], ENT_QUOTES, 'UTF-8') ?></p>
                        <p>手機號碼：<?= htmlspecialchars($data['phone'], ENT_QUOTES, 'UTF-8') ?></p>
                        <p>市話：<?= htmlspecialchars($data['homeTel'], ENT_QUOTES, 'UTF-8') ?></p>
                        <p>收件地址：<?= htmlspecialchars($data['homeAddress'], ENT_QUOTES, 'UTF-8') ?></p>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>無法獲取個人資料，請重新登入後再嘗試。</p>
            <?php endif; ?>
        </div>  
        <div class="button">
            <button type="button" onclick="window.location.href='my_order.php'">查看訂購紀錄</button>
            <button type="button" onclick="window.location.href='edit_profile.php?email=<?= $data['email'] ?>'">編輯個人資料</button>
        </div>
    </div>
    <div class="footer">
        <h2 id="title">世芳軒</h2>
        <div class="info">
            <p>世芳軒(阿魯伯)花生糖</p>
            地址:<a href="https://maps.app.goo.gl/KtiLPeaQFf3zNzmS8">台南市安定區蘇林里227號</a>
            <p>營業時間:早上7點到晚上7點</p>
            <p>電話:(06)5921003</p>
        </div>
        <a href="index.php" id="footer-link">回到首頁</a>    
    </div>
</body>
</html>
