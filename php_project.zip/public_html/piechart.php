<?php
// 連接資料庫
$link = mysqli_connect(
  'localhost', // MySQL 主機名稱
  'id22207720_user',      // 使用者名稱
  '*Uuser123',          // 密碼
  'id22207720_project'    // 預設使用的資料庫名稱
);

if(!$link) {
    die("無法開啟資料庫!<br/>");
}

// 每個商品的數量
$SQL = "
SELECT
    product_name,
    SUM(count) AS total_count
FROM (
    SELECT
        SUBSTRING_INDEX(details, ' ', 1) AS product_name,
        CAST(SUBSTRING_INDEX(details, ' ', -1) AS UNSIGNED) AS count
    FROM
        orders_list
) AS split_details
GROUP BY
    product_name;
";

$result = mysqli_query($link, $SQL);
?>

<html>
  <head>
    <meta charset="utf-8">
    <script defer="defer" src="order_list.bundle.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Product', 'Quantity']
          <?php
            while($row = mysqli_fetch_assoc($result)){
              $product = $row['product_name'];
              $quantity = $row['total_count'];
              echo ",['$product', $quantity]";
            }
          ?>
        ]);

        var options = {
          title: '銷售數量統計'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
  <header>
        <div class="logo">世芳軒</div>
        <nav>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "boss1") {
                $sessionStatus =  true;
                echo "
                            <a href='product_crispy.php'>脆枝商品列表</a>
                            <a href='product_otherCandy.php'>其他糖果商品列表</a>
                    ";
            } else if ($_SESSION["check"] == "boss2") {
                $sessionStatus =  true;
                echo "
                            <a href='product_peanut.php'>花生商品列表</a>
                            <a href='product_otherCandy.php'>其他糖果商品列表</a>
                    ";
            }
        }
        ?>
            <a href="order_list.php">訂單列表</a>
            <a href="index.php">首頁</a>
            <a href='logout.php'>登出</a>
        </nav>
    </header>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
