<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

// 獲取表單提交的資料
$productNo = $_POST['productNo'];
$productName = $_POST['productName'];
$productPrice = $_POST['productPrice'];
$productDescription = $_POST['productDescription'];

// 插入資料到資料庫
$sql = "INSERT INTO product_crispy (No, name, price, description) VALUES ('$productNo', '$productName', '$productPrice', '$productDescription')";

if (mysqli_query($link, $sql)) {
    echo "新商品新增成功!";
    // 跳轉回商品列表頁面
    header("Location: product_crispy.php");
} else {
    echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
}

// 關閉資料庫連接
mysqli_close($link);
?>