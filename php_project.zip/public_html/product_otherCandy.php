<!DOCTYPE html>
<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

// 從資料庫中獲取資料的函數
function fetchProductsFromDatabase($link) {
    $products = [];
    $sql = "SELECT * FROM product_otherCandy";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}

// 獲取訂單資料
$products = fetchProductsFromDatabase($link);

mysqli_close($link);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>商品列表</title>
    <link rel="stylesheet" href="https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Noto Sans TC', sans-serif;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #f4f4f4;
        }
        .nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #333;
        }
        .content {
            padding: 20px;
        }
        .categories {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .categories > div {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        .categories button {
            margin: 5px 0;
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        .categories button:hover {
            background-color: #0056b3;
        }
        .table-container {
            overflow-y: auto;
            max-height: 400px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .scroll-target {
            padding-top: 60px;
            margin-top: -60px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2 id="title">世芳軒</h2>
        <div class="nav">
            <a href="product_otherCandy.php">商品列表</a>
            <a href="order_list.php">訂單列表</a>
            <a href="index.php">首頁</a>
            <a href="logout.php">登出</a>
        </div>
    </div>
    <div class="content">
        <div class="ListofProducts">
            <h2 id="title">商品列表</h2>
            <div class="nav">
                <a href="newProduct_othercandy.html">新增商品</a>
            </div>
        </div>
        <div class="categories">
            <div>
                <h3>其他糖果</h3>
                <button onclick="scrollToCategory('cookie50')">50元餅乾</button>
                <button onclick="scrollToCategory('cookie100')">100元餅乾</button>
            </div>
        </div>
        <div class="table-container">
            <table id="productTable">
                <tr>
                    <th>商品名稱</th>
                    <th>商品價格</th>
                    <th>商品說明</th>
                    <th>操作</th>
                </tr>
                
                <?php
                foreach ($products as $product) {
                    if (isset($product['No'])) { // Ensure the 'No' key exists
                        echo "<tr>";
                        echo "<td>{$product['name']}</td>";
                        echo "<td>{$product['price']}</td>";
                        echo "<td>{$product['description']}</td>";
                        echo "<td>";
                        echo "<form action='editProduct_othercandy.php' method='get' style='display:inline;'>";
                        echo "<input type='hidden' name='No' value='{$product['No']}'>";
                        echo "<input type='submit' value='編輯'>";
                        echo "</form>";
                        echo "<form action='deleteProduct_othercandy.php' method='post' style='display:inline;'>";
                        echo "<input type='hidden' name='No' value='{$product['No']}'>";
                        echo "<input type='submit' value='刪除'>";
                        echo "</form>";
                        echo "</td>";
                        echo "</tr>";
                    } else {
                        echo "<tr><td colspan='4'>No 不存在</td></tr>";
                    }
                }
                ?>
            </table>
        </div>
    </div>
    <script>
        function scrollToCategory(category) {
            var element = document.getElementById(category);
            element.scrollIntoView({behavior: 'smooth'});
        }
    </script>
</body>
</html>
</body>
</html>