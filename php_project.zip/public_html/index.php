<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>世芳軒花生糖</title>
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="index.bundle.js"></script>
</head>

<body>
    <div class="header">
        <h2 id="title"><a href="index.php">世芳軒</h2>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "user") {
                $sessionStatus =  true;
                echo "<div class='nav'>
                        <a href='products.php'>查看所有商品</a>
                        <a href='profile.php'>個人資料</a>    
                        <a href='cart.php'>購物車</a>
                        <a href='logout.php'>登出</a>
                      </div>";
            } else if ($_SESSION["check"] == "guest") {
                echo "<div class='nav'>
                        <a href='products.php'>查看所有商品</a>
                        <a href='login.html'>登入</a>
                      </div>";
            }else if ($_SESSION["check"] == "boss1" || $_SESSION["check"] == "boss2"){
                echo "<div class='nav'>
                        <a href='order_list.php'>查看後台頁面</a>
                        <a href='products.php'>查看所有商品</a>
                        <a href='logout.php'>登出</a>
                      </div>";
            }
        } else {
            echo "<div class='nav'>
            <a href='products.php'>查看所有商品</a>
            <a href='login.html'>登入</a>    
            </div>";
        }
        ?>
    </div>
    <div class="content">
        <div class="cover">
            <h1 id="title">世芳軒花生糖</h1>
        </div>
        <div class="about">
            <h2>世芳軒(阿魯伯)的故事</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas veniam
                natus praesentium voluptas repellat possimus consectetur sint neque
                blanditiis, asperiores a voluptate eaque laboriosam dolores facilis
                itaque minima laudantium delectus.</p>
        </div>
        <div class="peanut">
            <h2>花生糖</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas veniam
                natus praesentium voluptas repellat possimus consectetur sint neque
                blanditiis, asperiores a voluptate eaque laboriosam dolores facilis
                itaque minima laudantium delectus.</p>
        </div>
        <div class="crispy">
            <h2>脆枝</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas veniam
                natus praesentium voluptas repellat possimus consectetur sint neque
                blanditiis, asperiores a voluptate eaque laboriosam dolores facilis
                itaque minima laudantium delectus.</p>
        </div>
        <div class="otherCandy">
            <h2>其它糖果</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas veniam
                natus praesentium voluptas repellat possimus consectetur sint neque
                blanditiis, asperiores a voluptate eaque laboriosam dolores facilis
                itaque minima laudantium delectus.</p>
        </div>
    </div>
    <div class="footer">
        <h2 id="title">世芳軒</h2>
        <div class="info">
            <p>世芳軒(阿魯伯)花生糖</p>
            地址:<a href="https://maps.app.goo.gl/KtiLPeaQFf3zNzmS8">台南市安定區蘇林里227號</a>
            <p>營業時間:早上7點到晚上7點</p>
            <p>電話:(06)5921003</p>
        </div>
        <a href="index.php" id="footer-link">回到首頁</a>
    </div>
</body>

</html>