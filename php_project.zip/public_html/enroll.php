<?php
$name = $_POST["name"];
$email = $_POST["email"];
$pwd = $_POST["password"];
$phone = $_POST["phone"];
$homeTel = $_POST["homeTel"];
$address = $_POST["address"];

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
$link = mysqli_connect(
    'localhost',
    'id22207720_user',
    '*Uuser123',
    'id22207720_project'
);

// Check connection
if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if email already exists
$checkEmailSql = "SELECT * FROM customer WHERE email = ?";
$stmt = mysqli_prepare($link, $checkEmailSql);
mysqli_stmt_bind_param($stmt, 's', $email);
mysqli_stmt_execute($stmt);
$emailResult = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($emailResult) > 0) {
    echo "<script type='text/javascript'>
            alert('email已經被註冊了~');
            window.location.href = 'enroll.html';
          </script>";
    mysqli_stmt_close($stmt);
    mysqli_close($link);
    exit;
}

// Check if phone already exists
$checkPhoneSql = "SELECT * FROM customer WHERE phone = ?";
$stmt = mysqli_prepare($link, $checkPhoneSql);
mysqli_stmt_bind_param($stmt, 's', $phone);
mysqli_stmt_execute($stmt);
$phoneResult = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($phoneResult) > 0) {
    echo "<script type='text/javascript'>
            alert('手機號碼已經被註冊了~');
            window.location.href = 'enroll.html';
          </script>";
    mysqli_stmt_close($stmt);
    mysqli_close($link);
    exit;
}

// Insert data into the database using prepared statements
$insertSql = "INSERT INTO customer(cName, email, pwd, phone, homeTel, homeAddress) 
              VALUES(?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($link, $insertSql);
mysqli_stmt_bind_param($stmt, 'ssssss', $name, $email, $pwd, $phone, $homeTel, $address);

if (mysqli_stmt_execute($stmt)) {
    echo "<script type='text/javascript'>
            alert('註冊成功～');
            window.location.href = 'login.html';
          </script>";
} else {
    echo "Error: " . mysqli_stmt_error($stmt);
}

mysqli_stmt_close($stmt); // Close statement
mysqli_close($link); // Close connection
?>
