<!DOCTYPE html>
<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

function fetchInfoFromDatabase($link) {
    $datas = [];
    $userInfoJson = $_COOKIE["userInfo"];
    
    // Convert the JSON string back to an associative array
    $userInfo = json_decode($userInfoJson, true);

    // Access the individual pieces of data
    $userName = $userInfo["userName"];

    $sql = "SELECT id, date, customer, status, SUM(amount) AS total_amount, GROUP_CONCAT(details) AS all_details
            FROM orders_list
            WHERE customer = '$userName'
            GROUP BY date, customer, status;";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $datas[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $datas;
}

// 獲取訂單資料
$datas = fetchInfoFromDatabase($link);

mysqli_close($link);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="cart.bundle.js"></script>
</head>
<body>
    <div class="header">
        <h2 id="title"><a href="index.php">世芳軒</a></h2>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "user") {
                echo "<div class='nav'>
                        <a href='products.php'>查看所有商品</a>
                        <a href='profile.php'>個人資料</a>    
                        <a href='cart.php'>購物車</a>
                        <a href='logout.php'>登出</a>
                      </div>";
            } else if ($_SESSION["check"] == "guest") {
                echo "<script type='text/javascript'>
                        alert(\"載入失敗\\n請登入後再查看此網頁\");
                        window.location.href = 'login.html';
                    </script>";
            }
        }
        ?>
    </div>
    <div class="content">
        <table>
            <h2>訂單資料</h2>
            <thead>
                <tr>
                    <th>訂單編號</th>
                    <th>日期</th>
                    <th>訂單狀態</th>
                    <th>總價</th>
                    <th>商品資訊：</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($datas)) : ?>
                    <?php foreach ($datas as $data) : ?>
                        <tr>
                            <td><?= $data['id'] ?></td>
                            <td><?= $data['date'] ?></td>
                            <td><?= $data['status'] ?></td>
                            <td>$<?= $data['total_amount'] ?></td>
                            <td><?= $data['all_details'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8">目前沒有訂單資料。</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="button">
            <button type="button" onclick="window.location.href='profile.php'">回到上一頁</button>
        </div>
    </div>
    <div class="footer">
        <h2 id="title">世芳軒</h2>
        <div class="info">
            <p>世芳軒(阿魯伯)花生糖</p>
            地址:<a href="https://maps.app.goo.gl/KtiLPeaQFf3zNzmS8">台南市安定區蘇林里227號</a>
            <p>營業時間:早上7點到晚上7點</p>
            <p>電話:(06)5921003</p>
        </div>
        <a href="index.php" id="footer-link">回到首頁</a>
    </div>
</body>
</html>
