<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if email and password are provided
if (!isset($_POST["email"]) || !isset($_POST["password"])) {
    echo "<script type='text/javascript'>
            alert(\"Email and password are required.\");
            window.location.href = 'login.html';
          </script>";
    exit();
}

$userEmail = $_POST["email"];
$userPwd = $_POST["password"];
$date = strtotime("+10 minutes");

// Database connection
$link = mysqli_connect('localhost', 'id22207720_user', '*Uuser123', 'id22207720_project');

// Check connection
if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepared statement to prevent SQL injection
$sql = "SELECT email, pwd, cName FROM customer WHERE email = ?";
$sql2 =  "SELECT email, pwd, name FROM boss WHERE email = ?";
$stmt = mysqli_prepare($link, $sql);
$stmt2 = mysqli_prepare($link, $sql2);

if ($stmt || $stmt2) {
    mysqli_stmt_bind_param($stmt, "s", $userEmail);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_param($stmt2, "s", $userEmail);
    mysqli_stmt_execute($stmt2);
    mysqli_stmt_store_result($stmt2);

    // Check if email exists and bind the result to variables
    if (mysqli_stmt_num_rows($stmt) > 0 || mysqli_stmt_num_rows($stmt2) > 0) {
        mysqli_stmt_bind_result($stmt, $email, $dbPwd, $userName); // Include cName in the bind result
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_bind_result($stmt2, $email, $dbPwd2, $userName2); 
        mysqli_stmt_fetch($stmt2);
        // Verify the password
        if ($userPwd === $dbPwd) {
            $_SESSION["check"] = "user";
            $_SESSION["userName"] = $userName; // Save cName as userName in the session
            // Create an array to hold the data
            $userData = array(
                "userName" => $userName,
                "date" => $date,
                "userEmail" => $userEmail,
                "userPwd" => $userPwd
            );

            // Convert the array to a JSON string
            $userDataJson = json_encode($userData);

            // Save the JSON string in a cookie
            setcookie("userInfo", $userDataJson, time() + (86400 * 30)); // 86400 = 1 day
            echo "<script type='text/javascript'>
                    alert(\"登入成功\");
                    window.location.href = 'products.php';
                  </script>";
        } else if ($userPwd === $dbPwd2){
            $_SESSION["check"] = $dbPwd2;
            // $_SESSION["bossName"] = $userName2; // Save cName as userName in the session
            setcookie("bossName", $userName2); // Save userName (cName) in a cookie
            echo "<script type='text/javascript'>
                    alert(\"登入成功\");
                    window.location.href = 'order_list.php';
                  </script>";
        }else{
            $_SESSION["check"] = "guest";
            echo "<script type='text/javascript'>
                    alert(\"登入失敗\\n請確認email和密碼都正確\");
                    window.location.href = 'login.html';
                  </script>";
        }
    } else {
        $_SESSION["check"] = "guest";
        echo "<script type='text/javascript'>
                alert(\"登入失敗\\n請確認email和密碼都正確\");
                window.location.href = 'login.html';
              </script>";
    }

    // Close statement
    mysqli_stmt_close($stmt);
} else {
    echo "Failed to prepare the SQL statement.";
}

// Close connection
mysqli_close($link);
?>
