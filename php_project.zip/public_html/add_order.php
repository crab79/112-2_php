<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>新增訂單</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="add_order.bundle.js"></script>
</head>
<body>
    <h1>新增訂單</h1>
    <form method="post" action="">
        <label for="date">訂單日期</label>
        <input type="date" id="date" name="date" required><br>
        
        <label for="customer">訂購人</label>
        <input type="text" id="customer" name="customer" required><br>
        
        <label for="status">狀態</label>
        <input type="text" id="status" name="status" required><br>
        
        <label for="amount">金額</label>
        <input type="number" id="amount" name="amount" required><br>
        
        <label for="details">訂單詳情</label>
        <textarea id="details" name="details" required></textarea><br>
        
        <button type="submit">新增</button>
        <button type="button" onclick="window.location.href='order_list.php'">取消</button>
    </form>
</body>
</html>
<?php
//連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);
if(!$link)
    die("無法開啟資料庫!<br/>");
else
    echo "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['date'];
    $customer = $_POST['customer'];
    $status = $_POST['status'];
    $amount = $_POST['amount'];
    $details = $_POST['details'];

    // 將新訂單保存到資料庫
    $sql = "INSERT INTO orders_list (date, customer, status, amount, details) VALUES ('$date', '$customer', '$status', '$amount', '$details')";

    if (mysqli_query($link, $sql) === TRUE) {
        // 保存成功後重新導到訂單列表
        header('Location: order_list.php');
        exit;
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }
}

mysqli_close($link);
?>