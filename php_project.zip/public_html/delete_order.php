<!DOCTYPE html>
<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = $_POST['order_id'];
    
    if (!empty($orderId)) {
        $sql = "DELETE FROM orders_list WHERE id = ?";
        $stmt = mysqli_prepare($link, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $orderId);
            
            if (mysqli_stmt_execute($stmt)) {
                $message = "訂單刪除成功!";
            } else {
                $message = "刪除失敗" . mysqli_stmt_error($stmt);
            }
            
            mysqli_stmt_close($stmt);
        } else {
            $message = "準備語句失敗: " . mysqli_error($link);
        }
    } else {
        $message = "未指定訂單 ID";
    }
}

mysqli_close($link);
?>


<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>刪除訂單</title>
    <style>
        .message-box {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            z-index: 1000;
        }
    </style>
    <script>
        function redirectToOrderList() {
            setTimeout(function() {
                window.location.href = 'order_list.php';
            }, 3000);
        }
    </script>
</head>
<body onload="redirectToOrderList()">
    <div class="message-box">
        <p><?php echo $message; ?></p>
    </div>
</body>
</html>
