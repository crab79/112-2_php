<!DOCTYPE html>
<?php
// editProduct_othercandy.php
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);
if (!$link) {
    die("無法開啟資料庫!<br/>");
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['No'])) {
    $no = $_GET['No'];
    $sql = "SELECT * FROM product_otherCandy WHERE No = $no";
    $result = mysqli_query($link, $sql);
    $product = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $no = $_POST['No'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    $sql = "UPDATE product_othercandy SET name='$name', price='$price', description='$description' WHERE No='$no'";
    if (mysqli_query($link, $sql)) {
        header('Location: product_otherCandy.php');
        exit();
    } else {
        echo "錯誤: " . mysqli_error($link);
    }
}

mysqli_close($link);
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>編輯商品資訊</title>
    <style>
        body {
            font-family: 'Noto Sans TC', sans-serif;
            background-color: #f4f4f4;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #f4f4f4;
        }
        .nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #333;
        }
        .content {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: #f8e0a6;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        .form-container h2 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group textarea {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-group input[type="submit"], .form-group .btn-secondary {
            width: calc(50% - 12px);
            padding: 10px;
            border-radius: 4px;
            box-sizing: border-box;
            text-align: center;
            cursor: pointer;
            font-size: 14px;
            margin: 5px;
        }
        .form-group input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
        }
        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .form-group .btn-secondary {
            background-color: #dc3545;
            color: white;
            border: none;
            text-decoration: none;
            display: inline-block;
        }
        .form-group .btn-secondary:hover {
            background-color: #c82333;
        }
        .button-container {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>世芳軒</h2>
        <div class="nav">
            <a href="product_otherCandy.php">商品列表</a>
            <a href="order_list.php">訂單列表</a>
            <a href="index.php">首頁</a>
            <a href="logout.php">登出</a>
        </div>
    </div>
    <div class="content">
        <div class="form-container">
            <h2>編輯商品資訊</h2>
            <?php if (isset($product)) { ?>
            <form action="editProduct_othercandy.php" method="post">
                <div class="form-group">
                    <label for="No">商品名稱:</label>
                    <input type="text" id="No" name="No" value="<?php echo $product['No']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="name">商品名稱:</label>
                    <input type="text" id="name" name="name" value="<?php echo $product['name']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="price">商品價格:</label>
                    <input type="text" id="price" name="price" value="<?php echo $product['price']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="description">商品說明:</label>
                    <textarea id="description" name="description" required><?php echo $product['description']; ?></textarea>
                </div>
                <div class="form-group button-container">
                    <input type="submit" value="確認編輯">
                    <a href="product_otherCandy.php" class="btn-secondary">取消</a>
                </div>
            </form>
            <?php } else { ?>
                <p>未找到商品。</p>
            <?php } ?>
        </div>
    </div>
</body>
</html>
