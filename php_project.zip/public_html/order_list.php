<!DOCTYPE html>
<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

// 從資料庫中獲取訂單資料的函數
function fetchOrdersFromDatabase($link) {
    $orders = [];
    $sql = "SELECT id, date, customer, status, SUM(amount) AS total_amount, GROUP_CONCAT(details) AS all_details
            FROM orders_list
            GROUP BY date, customer, status;";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $orders[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $orders;
}

// 獲取訂單資料
$orders = fetchOrdersFromDatabase($link);

mysqli_close($link);
?>
<html lang="zh-TW">
<head>
<head>
    <meta charset="UTF-8">
    <title>訂單列表</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="order_list.bundle.js"></script>
</head>

</head>
<body>
    <header>
        <div class="logo">世芳軒</div>
        <nav>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "boss1") {
                $sessionStatus =  true;
                echo "
                            <a href='product_crispy.php'>脆枝商品列表</a>
                            <a href='product_otherCandy.php'>其他糖果商品列表</a>
                    ";
            } else if ($_SESSION["check"] == "boss2") {
                $sessionStatus =  true;
                echo "
                            <a href='product_peanut.php'>花生商品列表</a>
                            <a href='product_otherCandy.php'>其他糖果商品列表</a>
                    ";
            }
        }
        ?>
            <a href="order_list.php">訂單列表</a>
            <a href="index.php">首頁</a>
            <a href='logout.php'>登出</a>
        </nav>
    </header>
    <main>
        <h1>訂單列表</h1>
        <div class="actions">
            <!-- <button class="btn-new" onclick="window.location.href='add_order.php'">新增訂單</button>
            <button class="btn-delete">刪除訂單</button> -->
            <button class="btn-new" onclick="window.location.href='add_order.php'">新增訂單</button>
            <button class="btn-new" onclick="window.location.href='piechart.php'">銷售量</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th><input type="checkbox"></th>
                    <th>訂單編號</th>
                    <th>訂單日期</th>
                    <th>訂購人</th>
                    <th>訂單詳情</th>
                    <th>金額</th>
                    <th>狀態</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($orders)) : ?>
                    <?php foreach ($orders as $order) : ?>
                        <tr>    
                            <td><input type="checkbox"></td>
                            <td><a href="order_details.php?id=<?= $order['id'] ?>"><?= $order['id'] ?></a></td>
                            <td><?= $order['date'] ?></td>
                            <td><?= $order['customer'] ?></td>
                            <td><?= $order['all_details'] ?></td>
                            <td>$<?= $order['total_amount'] ?></td>
                            <td><?= $order['status'] ?></td>
                            <td>
                                <button class="btn-edit" onclick="window.location.href='edit_order.php?id=<?= $order['id'] ?>'">編輯</button>
                                <form action="delete_order.php" method="post" style="display:inline;">
                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                    <button type="submit" class="btn-delete">刪除</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8">目前沒有訂單資料。</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
