<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="cart.bundle.js"></script>
</head>

<body>
    <div class="header">
        <h2 id="title"><a href="index.php">世芳軒</a></h2>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "user") {
                echo "<div class='nav'>
                            <a href='products.php'>查看所有商品</a>
                            <a href='profile.php'>個人資料</a>    
                            <a href='cart.php'>購物車</a>
                            <a href='logout.php'>登出</a>
                          </div>";
            } else if ($_SESSION["check"] == "guest") {
                echo "<script type='text/javascript'>
                            alert(\"載入失敗\\n請登入後再查看此網頁\");
                            window.location.href = 'login.html';
                        </script>";
            }
        }
        ?>
    </div>
    <div class="content">
        <table>
            <thead>
                <tr>
                    <th>產品名稱</th>
                    <th>數量</th>
                    <th>金額</th>
                </tr>
            </thead>
            <tbody id="productDetailsContainer">
            </tbody>
        </table>
        <button onclick="submitOrder()">送出訂單</button>
        <button onclick="clearProductData()">清空購物車</button>
        <?php
        session_start();
        // Handle product data from form submission
        // if (isset($_POST['product_name'], $_POST['product_quantity'], $_POST['product_price'])) {
        //     $product_name = $_POST['product_name'];
        //     $quantity = $_POST['product_quantity'];
        //     $product_price = $_POST['product_price'];
        //     $total_price = $product_price * $quantity;

        //     // Create product array
        //     $product = array(
        //         'name' => $product_name,
        //         'price' => $product_price,
        //         'amount' => $quantity,
        //         'total_price' => $total_price
        //     );

        //     // Retrieve existing product data from session
        //     $existing_product_data = isset($_SESSION['product']) ? $_SESSION['product'] : array();

        //     // Add new product data to the existing product data
        //     $existing_product_data[] = $product;

        //     // Store updated product data in session
        //     $_SESSION['product'] = $existing_product_data;

        //     // Encode the updated product data to JSON
        //     $updated_product_json = json_encode($existing_product_data);

        //     // Generate JavaScript code to set the combined product data in localStorage
        //     $js_code = "localStorage.setItem('product', '" . addslashes($updated_product_json) . "');";
        //     echo "<script>$js_code</script>"; // Output JavaScript code
        // }
        ?>
    </div>

    <div class="footer">
        <h2 id="title">世芳軒</h2>
        <div class="info">
            <p>世芳軒(阿魯伯)花生糖</p>
            地址:<a href="https://maps.app.goo.gl/KtiLPeaQFf3zNzmS8">台南市安定區蘇林里227號</a>
            <p>營業時間:早上7點到晚上7點</p>
            <p>電話:(06)5921003</p>
        </div>
        <a href="index.php" id="footer-link">回到首頁</a>
    </div>
    <script>
        displayProductDetails();

        function displayProductDetails() {
            // Retrieve product data from localStorage
            const productData = localStorage.getItem('product');

            // Parse JSON string to array of product objects
            const products = JSON.parse(productData);

            // Get the container element
            const container = document.getElementById('productDetailsContainer');
            const content = document.getElementsByClassName('content');

            let order_total_price = 0;
            // Check if products exist in localStorage
            if (products && products.length > 0) {
                // Clear previous content
                container.innerHTML = '';
                // Loop through each product
                products.forEach(product => {
                    // Create a div element for each product
                    // Set inner HTML for the product div
                    container.innerHTML += `<tr>
                                        <td>${product.name}</td>
                                        <td>${product.amount}</td>
                                        <td>${product.total_price}</td>
                                    </tr>
                                            `; // Add a horizontal line between products
                    order_total_price += product.total_price;
                    // Append the product div to the container
                });
                const table = document.getElementsByTagName('table');
                const totalH2 = document.createElement('h2');
                totalH2.innerHTML = `<h2>總共金額：${order_total_price}</h2>`;
                table[0].appendChild(totalH2);
            } else {
                // Display a message if no products are found
                content[0].innerHTML = '';
                content[0].innerHTML = "<h2>您還沒有選購喔～</h2>";
            }

        }

        // Function to clear product data from localStorage and session
        function clearProductData() {
            // Make an AJAX call to unset the session variable
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'clear_session.php', true);
            xhr.send();

            // Clear product data from localStorage
            localStorage.removeItem('product');
            alert('購物車幫您清空了～'); // Display an alert

            displayProductDetails()
        }

        function submitOrder() {
            const products = JSON.parse(localStorage.getItem('product'));
            console.log('Products before sending:', products); // Log the products before sending

            const formattedProducts = products.map(product => ({
                name: product.name,
                price: parseFloat(product.price), // Convert to number using parseFloat
                amount: parseInt(product.amount), // Convert to number using parseInt
                total_price: parseFloat(product.price) * parseInt(product.amount)
            }));


            fetch('submitOrder.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        products: formattedProducts
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    const xhr = new XMLHttpRequest();
                    xhr.open('GET', 'clear_session.php', true);
                    xhr.send();

                    // Clear product data from localStorage
                    localStorage.removeItem('product');
                    alert("訂單送出成功！購物車幫您清空了～"); // Display an alert
                    displayProductDetails()
                })
                .catch(error => {
                    alert('Error submitting products: ' + error.message); // Display an alert with the error message
                    console.error('Error:', error);
                });
        }
    </script>
</body>

</html>