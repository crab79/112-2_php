<?php
header('Content-Type: application/json');

// Check if raw POST data is available and decode it
$data = file_get_contents('php://input');
$request = json_decode($data, true);

// Check if products data is available in the request
if (isset($request['products'])) {
    // Database connection parameters
    $servername = "localhost";
    $username = "id22207720_user";
    $password = "*Uuser123";
    $dbname = "id22207720_project";

    // Connect to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        exitWithError('Database connection failed: ' . $conn->connect_error);
    }

    // Start building the SQL query
    $sql = "INSERT INTO orders_list (date, customer, status, amount, details) VALUES ";

    $products = $request['products'];
    $values = [];

    foreach ($products as $product) {

        if(isset($_COOKIE["userInfo"])) {
            // Retrieve the JSON string from the cookie
            $userInfoJson = $_COOKIE["userInfo"];
        
            // Convert the JSON string back to an associative array
            $userInfo = json_decode($userInfoJson, true);
        
            // Access the individual pieces of data
            $userName = $userInfo["userName"];
            $date = $userInfo["date"];
            $userEmail = $userInfo["userEmail"];
            $userPwd = $userInfo["userPwd"];
        }

        // Set parameters
        $date = date('Y-m-d H:i:s'); 
        $customer = isset($_COOKIE['userInfo']) ? $userName : null; // Retrieve customer name from cookie
        $status = '未出貨'; // Default status
        $amount = $product['total_price'];
        $details = $product['name'] . ' ' . $product['amount'];

        // Escape special characters to prevent SQL injection
        $date = $conn->real_escape_string($date);
        $customer = $conn->real_escape_string($customer);
        $status = $conn->real_escape_string($status);
        $amount = $conn->real_escape_string($amount);
        $details = $conn->real_escape_string($details);

        // Build the values part of the SQL query
        $values[] = "('$date', '$customer', '$status', '$amount', '$details')";
    }

    // Combine all values into a single SQL query
    $sql .= implode(",", $values);

    // Execute the SQL query
    if ($conn->query($sql) === TRUE) {
        // Return success message
        echo json_encode(['message' => 'Products submitted successfully!']);
    } else {
        // Return error response
        exitWithError('SQL Execution Error: ' . $conn->error);
    }

    // Close connection
    $conn->close();
} else {
    // Return error message if no products data is available
    exitWithError('Bad Request: No products to submit.');
}

function exitWithError($errorMessage) {
    http_response_code(500);
    echo json_encode(['error' => $errorMessage]);
    exit;
}
?>
