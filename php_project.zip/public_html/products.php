<!DOCTYPE html>

<?php
// 連接資料庫
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

function fetchPeanutFromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_peanut
            WHERE name LIKE '%花生%'
            AND name NOT LIKE '%芝麻%'
            ";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}
function fetchSeasameFromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_peanut
            WHERE name LIKE '%芝麻%'
            AND name NOT LIKE '%花生%'
            ";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}
function fetchPeanutSeasameFromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_peanut
            WHERE name LIKE '%芝麻花生%'
            ";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}
// 從資料庫中獲取資料的函數
function fetchCrispyFromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_crispy
            WHERE name LIKE '%脆枝%'";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}

function fetchRollFromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_crispy
            WHERE name LIKE '%麻花捲%'";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}

function fetchOtherCandy50FromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_otherCandy
            WHERE price = 50";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}
function fetchOtherCandy100FromDatabase($link)
{
    $products = [];
    $sql = "SELECT * FROM product_otherCandy
            WHERE price = 100";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    return $products;
}

// 獲取訂單資料
$products_peanut = fetchPeanutFromDatabase($link);
$products_seasame = fetchSeasameFromDatabase($link);
$products_peanutSeasame = fetchPeanutSeasameFromDatabase($link);
$products_crispy = fetchCrispyFromDatabase($link);
$products_roll = fetchRollFromDatabase($link);
$products_otherCandy50 = fetchOtherCandy50FromDatabase($link);
$products_otherCandy100 = fetchOtherCandy100FromDatabase($link);

mysqli_close($link);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="products.bundle.js"></script>
</head>

<body>
    <div class="header">
        <h2 id="title"><a href="index.php">世芳軒</a></h2>
        <?php
        session_start();
        if (isset($_SESSION["check"])) {
            if ($_SESSION["check"] == "user") {
                $sessionStatus =  true;
                echo "<div class='nav'>
                        <a href='products.php'>查看所有商品</a>
                        <a href='profile.php'>個人資料</a>    
                        <a href='cart.php'>購物車</a>
                        <a href='logout.php'>登出</a>
                      </div>";
            } else if ($_SESSION["check"] == "guest") {
                echo "<div class='nav'>
                        <a href='products.php'>查看所有商品</a>
                        <a href='login.html'>登入</a>    
                      </div>";
            }
        } else {
            echo "<div class='nav'>
            <a href='products.php'>查看所有商品</a>
            <a href='login.html'>登入</a>    
            </div>";
        }
        ?>
    </div>
    <div class="content">
        <div class="sidebar">
            <div class="series">
                <h5>花生糖</h5>
                <button class="button-6" id="peanut" role="button">花生系列</button>
                <button class="button-6" id="seasame" role="button">芝麻系列</button>
                <button class="button-6" id="peanut-seasame" role="button">花生芝麻系列</button>
            </div>
            <div class="series">
                <h5>脆枝/麻花捲系列</h5>
                <button class="button-6" id="crispy" role="button">脆枝系列</button>
                <button class="button-6" id="rolling" role="button">麻花捲系列</button>
            </div>
            <div class="series">
                <h5>其他糖果</h5>
                <button class="button-6" id="50dollars" role="button">50元餅乾</button>
                <button class="button-6" id="100dollars" role="button">100元餅乾</button>
            </div>
        </div>
        <div class="products">
            <div id="sessionStatus" data-status="<?php echo $sessionStatus; ?>"></div>
            <!-- <div class="product">
                    <img src="https://www.hug.com.tw/uploads/images/product_photos/p_o_1dse9uqlacoc1eiv3bkesa1lat7.jpg" alt="a picture of peanust candy">
                    <h3>花生硬糖</h3>
                    <h3>$200/罐</h3>
                </div> -->

        </div>
    </div>
    <div class="footer">
        <h2 id="title">世芳軒</h2>
        <div class="info">
            <p>世芳軒(阿魯伯)花生糖</p>
            地址:<a href="https://maps.app.goo.gl/KtiLPeaQFf3zNzmS8">台南市安定區蘇林里227號</a>
            <p>營業時間:早上7點到晚上7點</p>
            <p>電話:(06)5921003</p>
        </div>
        <a href="index.php" id="footer-link">回到首頁</a>
    </div>
    <script>
        const sessionStatus = document.getElementById('sessionStatus').getAttribute('data-status');

        const rightPart = document.getElementsByClassName("products");
        const make_product = (name, price, img) => {
            const form = document.createElement('form');
            form.setAttribute('action', 'check_cart.php');
            form.setAttribute('method', 'post');
            const label = document.createElement('label');
            label.setAttribute('for', 'quantity');
            label.textContent = '數量:';
            const input_product = document.createElement('input');
            const input_product_price = document.createElement('input');
            const input = document.createElement('input');
            input.setAttribute('type', 'number');
            input_product.setAttribute('type', 'hidden');
            input_product_price.setAttribute('type', 'hidden');
            input.setAttribute('id', 'quantity');
            input.setAttribute('name', 'product_quantity');
            input.setAttribute('min', '1');
            input.setAttribute('max', '10');
            input.setAttribute('step', '1');
            input.setAttribute('value', '1');
            input_product.setAttribute('value', name);
            input_product.setAttribute('name', 'product_name');
            input_product_price.setAttribute('value', price);
            input_product_price.setAttribute('name', 'product_price');
            const button = document.createElement('button');
            button.setAttribute('type', 'submit');
            button.textContent = '加到購物車';
            const productElement = document.createElement('div');
            productElement.className = "product";
            const foodImg = document.createElement('img');
            const product_name = document.createElement('h3');
            const product_price = document.createElement('h3');
            foodImg.src = img;
            product_name.innerText = name;
            product_price.innerText = price;
            productElement.append(foodImg);
            productElement.append(product_name);
            productElement.append(product_price);
            if (sessionStatus == true) {
                form.append(input_product);
                form.append(input_product_price);
                form.append(label);
                form.append(input);
                form.append(button);
                productElement.append(form);
            }
            rightPart[0].append(productElement);
        };
        const peanut = document.getElementById("peanut");
        const seasame = document.getElementById("seasame");
        const peanut_seasame = document.getElementById("peanut-seasame");
        const crispy = document.getElementById("crispy");
        const rolling = document.getElementById("rolling");
        const _50dollars = document.getElementById("50dollars");
        const _100dollars = document.getElementById("100dollars");

        peanut.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_peanut); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })

        seasame.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_seasame); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })

        peanut_seasame.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_peanutSeasame); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })

        crispy.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_crispy); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })

        rolling.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_roll); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })

        _50dollars.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_otherCandy50); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })

        _100dollars.addEventListener('click', () => {
            rightPart[0].innerText = '';
            const products = <?php echo json_encode($products_otherCandy100); ?>;
            products.forEach(product => {
                make_product(product.name, product.price, product.img);
            });
        })
    </script>
</body>

</html>