<!DOCTYPE html>
<?php

// 連接資料庫

$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);

if (!$link) {
    die("無法開啟資料庫!<br/>");
}

$order_id = $_GET['id'];

// 從資料庫中取得訂單詳情
$sql = "SELECT * FROM orders_list WHERE id = $order_id";
$result = mysqli_query($link, $sql);

if ($result) {
    $order = mysqli_fetch_assoc($result);
} else {
    echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['date'];
    $customer = $_POST['customer'];
    $status = $_POST['status'];
    $amount = $_POST['amount'];
    $details = $_POST['details'];

    // 更新訂單到資料庫
    $sql = "UPDATE orders_list SET date='$date', customer='$customer', status='$status', amount='$amount', details='$details' WHERE id=$order_id";

    if (mysqli_query($link, $sql)) {
        // 保存成功後重新導到訂單列表
        header('Location: order_list.php');
        exit;
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }
}

mysqli_close($link);
?>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>編輯訂單</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script defer="defer" src="edit_order.bundle.js"></script>
</head>
<body>
    <h1>編輯訂單</h1>
    <form method="post" action="">
        <label for="date">訂單日期</label>
        <input type="datetime-local" id="date" name="date" value="<?= $order['date'] ?>" required><br>
        
        <label for="customer">訂購人</label>
        <input type="text" id="customer" name="customer" value="<?= $order['customer'] ?>" required><br>
        
        <label for="status">狀態</label>
        <input type="text" id="status" name="status" value="<?= $order['status'] ?>" required><br>
        
        <label for="amount">金額</label>
        <input type="number" id="amount" name="amount" value="<?= $order['amount'] ?>" required><br>
        
        <label for="details">訂單詳情</label>
        <textarea id="details" name="details" required><?= $order['details'] ?></textarea><br>
        
        <button type="submit">保存</button>
        <button type="button" onclick="window.location.href='order_list.php'">取消</button>
    </form>
</body>
</html>
