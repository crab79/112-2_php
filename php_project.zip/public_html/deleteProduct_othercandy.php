<?php
// deleteProduct_othercandy.php
$link = mysqli_connect(
    'localhost', // MySQL 主機名稱
    'id22207720_user',      // 使用者名稱
    '*Uuser123',          // 密碼
    'id22207720_project'    // 預設使用的資料庫名稱
);
if (!$link) {
    die("無法開啟資料庫!<br/>");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['No'])) {
    $no = $_POST['No'];
    $sql = "DELETE FROM product_othercandy WHERE No = $no";
    
    if (mysqli_query($link, $sql)) {
        header('Location: product_othercandy.php');
    } else {
        echo "錯誤: " . mysqli_error($link);
    }
} else {
    echo "無效的請求";
}

mysqli_close($link);
?>