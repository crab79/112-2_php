    <!DOCTYPE html>
    <?php
    // 連接資料庫
    $link = mysqli_connect(
        'localhost', // MySQL 主機名稱
        'id22207720_user',      // 使用者名稱
        '*Uuser123',          // 密碼
        'id22207720_project'    // 預設使用的資料庫名稱
    );

    if (!$link) {
        die("無法開啟資料庫!<br/>");
    }

    $customer_email = $_GET['email'];

    $sql = "SELECT * FROM customer WHERE email = '$customer_email'";
    $result = mysqli_query($link, $sql);
    $profile = [];
    if ($result) {
        $profile = mysqli_fetch_assoc($result);
    } else {
        echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $pwd = $_POST["password"];
        $phone = $_POST["phone"];
        $homeTel = $_POST["homeTel"];
        $address = $_POST["address"];

        // 更新訂單到資料庫
        $sql = "UPDATE customer SET cName='$name', email='$email', pwd='$pwd', phone='$phone', homeTel='$homeTel', homeAddress='$address' WHERE email = '$customer_email'";

        if (mysqli_query($link, $sql)) {
            // 保存成功後重新導到訂單列表
            echo "<script type='text/javascript'>
                    alert('修改成功');
                    window.location.href = 'profile.php';
                </script>";
        } else {
            echo "錯誤: " . $sql . "<br>" . mysqli_error($link);
        }
    }

    mysqli_close($link);

    ?>
    <html lang="zh-TW">
    <head>
        <meta charset="UTF-8">
        <title>編輯個人資料</title>
        <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-straight/css/uicons-solid-straight.css'>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
        <script defer="defer" src="enroll.bundle.js"></script>
    </head>
    <body>
    <div class="header">
            <h2 id="title"><a href="index.php">世芳軒</a></h2>
            <?php
            session_start();
            if (isset($_SESSION["check"])) {
                if ($_SESSION["check"] == "user") {
                    echo "<div class='nav'>
                            <a href='products.php'>查看所有商品</a>
                            <a href='profile.php'>個人資料</a>    
                            <a href='cart.php'>購物車</a>
                            <a href='logout.php'>登出</a>
                        </div>";           
                } else if ($_SESSION["check"] == "guest") {
                    echo "<script type='text/javascript'>
                            alert(\"載入失敗\\n請登入後再查看此網頁\");
                            window.location.href = 'login.html';
                        </script>";
                }
            }
            ?>
        </div>
        <div class="content">
            <form action="" method="post">
                <h2>編輯個人資料</h2>
                <div class="login">
                    <div class="field">
                        <label for="name">姓名(必填):</label>
                        <input type="text" name="name" id="name" required value="<?= $profile['cName'] ?>">       
                    </div>
                    <div class="field">
                        <label for="email">電子郵件(必填):</label>
                        <input type="email" name="email" id="email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" value="<?= $profile['email'] ?>" >       

                    </div>
                    <div class="field">
                        <label for="pwd">密碼:</label>
                        <input type="password" name="password" id="pwd" value="<?= $profile['pwd'] ?>"  >   
                    </div>
                    <div class="field">
                        <label for="pwd">再輸入一次密碼:</label>
                        <input type="password" name="password" id="pwd2" value="<?= $profile['pwd'] ?>" >           
                    </div>
                </div>
                <hr>
                <div class="info">
                    <div class="field">
                        <label for="phone">手機號碼(必填):</label>
                        <input type="text" id="phone" name="phone" required pattern="^09[0-9]{8}$" value="<?= $profile['phone'] ?>">    
                    </div>
                    <div class="field">
                        <label for="homeTel">市話(選填):</label>
                        <input type="text" name="homeTel" id="homeTel" value="<?= $profile['homeTel'] ?>">           
                    </div>
                    <div class="field">
                        <label for="address">收件地址(必填):</label>
                        <input type="text" name="address" id="address" required value="<?= $profile['homeAddress'] ?>">               
                    </div>
                </div>
                <input type="submit" value="送出" id="submit">
            </form>
        </div>
        <div class="footer">
            <h2 id="title">世芳軒</h2>
            <div class="info">
                <p>世芳軒(阿魯伯)花生糖</p>
                地址:<a href="https://maps.app.goo.gl/KtiLPeaQFf3zNzmS8">台南市安定區蘇林里227號</a>
                <p>營業時間:早上7點到晚上7點</p>
                <p>電話:(06)5921003</p>
            </div>
            <a href="index.php" id="footer-link">回到首頁</a>    
        </div>
    </body>
    </html>
