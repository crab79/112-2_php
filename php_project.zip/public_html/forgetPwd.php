<?php
$email = $_POST["email"];
$phone = $_POST["phone"];
$subject = "世芳軒-會員密碼找回信";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

// Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
$link = mysqli_connect(
    'localhost',
    'id22207720_user',
    '*Uuser123',
    'id22207720_project'
);

// Check connection
if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare an SQL statement
$stmt = $link->prepare("SELECT pwd, cName FROM customer WHERE email = ? AND phone = ?");
$stmt->bind_param("ss", $email, $phone);

// Execute the query
$stmt->execute();

// Bind the result to variables
$stmt->bind_result($password, $name);

// Fetch the result and process it
if ($stmt->fetch()) {
    $context = "親愛的".$name."您好！您的密碼是".'<br/>'."密碼: " . htmlspecialchars($password);
    try {
        // Server settings
        $mail->SMTPDebug = false; // Disable verbose debug output
        $mail->isSMTP(); // Send using SMTP
        $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true; // Enable SMTP authentication
        $mail->Username   = 'hanyaoyao0709@gmail.com'; // SMTP username
        $mail->Password   = 'rigq hvjl saad hove'; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable implicit TLS encryption
        $mail->Port       = 465; // TCP port to connect to
        $mail->CharSet    = 'utf-8';

        // Recipients
        $mail->setFrom('ma4815162342@yahoo.com', '世芳軒');
        $mail->addAddress($email, htmlspecialchars($name)); // Add a recipient

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $context;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        echo "<script type='text/javascript'>
        alert('密碼找回信 寄送成功！');
        window.location.href = 'login.html';
        </script>";

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
            echo "<script type='text/javascript'>
                alert(\"查詢失敗\\n請確認email和密碼都正確\");
                window.location.href = 'forgetPwd.html';
              </script>";
}

// Close the statement and connection
$stmt->close();
mysqli_close($link);
?>
