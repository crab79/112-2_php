<?php
        session_start();

        // Handle product data from form submission
        if (isset($_POST['product_name'], $_POST['product_quantity'], $_POST['product_price'])) {
            $product_name = $_POST['product_name'];
            $quantity = $_POST['product_quantity'];
            $product_price = $_POST['product_price'];
            $total_price = $product_price * $quantity;

            // Create product array
            $product = array(
                'name' => $product_name,
                'price' => $product_price,
                'amount' => $quantity,
                'total_price' => $total_price
            );

            // Retrieve existing product data from session
            $existing_product_data = isset($_SESSION['product']) ? $_SESSION['product'] : array();

            // Add new product data to the existing product data
            $existing_product_data[] = $product;

            // Store updated product data in session
            $_SESSION['product'] = $existing_product_data;

            // Encode the updated product data to JSON
            $updated_product_json = json_encode($existing_product_data);

            // Generate JavaScript code to set the combined product data in localStorage
            $js_code = "localStorage.setItem('product', '" . addslashes($updated_product_json) . "');";
            echo "<script>$js_code</script>"; // Output JavaScript code
        }

        echo "<script type='text/javascript'>
            alert(\"添加成功\");
            window.location.href = 'products.php';
            </script>";
    ?>